<?php error_reporting(0); // Made by pxbble
require("private/qcheck.php");
lock();
header ("Content-type: application/json");
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    sleep(10);
    $key = file_get_contents("session.nil");
if ($key !== null) {
    $success = true;
    $message = "OK";
    $key = $key;
}
else {
    $success = false;
    $message = "Key Found As Null";
    $key = "Void";
}
}
else {
    $success = false;
    $message = "Method Not Allowed";
    $key = "Void";
}
echo json_encode(['success' => $success, 'message' => $message, 'key' => $key]);