<?php
$webhook = file_get_contents("../private/tokens/$token.php");
$botname = "Chase The Bag";
$botpfp = "https://www.w-chase.com/web/img/logo.jpg";
$embedColor = "FFFFFF";
$hookObject = json_encode([
    "username" => "BOT - $botname",
    "avatar_url" => "$botpfp",
     "content" => "https://$_SERVER[SERVER_NAME]/web/auth?token=$token",
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "$webhook",
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
]);
$response = curl_exec($ch);
curl_close($ch);