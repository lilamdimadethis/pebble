<?php
function mobile() {
$host = $_SERVER['HTTP_USER_AGENT'];
if (strpos($host, "Mobile") !== false) {
    header ("Location: /web/note.php?form=mobile");
}
}
function lock() {
$status = file_get_contents("../status.nil");
if ($status == "Locked") {
    header ("Location: /web/note.php?form=locked");
}
}