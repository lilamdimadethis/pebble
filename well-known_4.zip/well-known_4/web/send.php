<?php error_reporting(0); // Made by pxbble
require("../private/qcheck.php");
lock();
header ("Content-type: application/json");
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    sleep(1);
    $token = $_GET['token'];
    if (file_exists("../private/tokens/$token.php")) {
        require("../private/embeds.php");
        $success = true;
        $message = "OK";
    }
    else {
        $success = false;
        $message = "Invalid Token";
    }
}
else {
    $success = false;
    $message = "Method Not Allowed";
}
echo json_encode(['success' => $success, 'message' => $message]);