<?php error_reporting(0); // Made by pxbble
require("../private/qcheck.php");
lock();
header ("Content-type: application/json");
if ($_SERVER['REQUEST_METHOD'] == "POST") {
sleep(1);
if ($_GET['key']) {
    $key = file_get_contents("../session.nil");
    if ($_GET['key'] == $key) {
        $success = true;
        $message = "OK";
        setcookie("session", $_GET['key']);
    }
    else {
        $success = false;
        $message = "Incorrect Key";
    }
}
if ($_GET['webhook']) {
    $a = file_get_contents($_GET['webhook']);
    $b = json_decode($a, true);
    $c = $b['id'];
    if ($c !== null) {
        $webhook = $_GET['webhook'];
        $tokens = array("1A55A9DB5FCED", "E7CEF4B37EBBD");
        $random = mt_rand(0, 1);
        $token = str_shuffle($tokens[$random]);
        file_put_contents("../private/tokens/$token.php", $webhook);
        $success = true;
        $message = $token;
    }
    else {
        $success = false;
        $message = "Invalid Webhook";
    }
}
if (!$_GET['key'] and !$_GET['webhook']) {
    $success = false;
    $message = "Value Cannot Be Null";
}
}
else {
    $success = false;
    $message = "Method Not Allowed";
}
echo json_encode(['success' => $success, 'message' => $message]);