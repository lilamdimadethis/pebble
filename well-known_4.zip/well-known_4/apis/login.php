<?php
require("uri.php");
header ("Content-type: application/json");
if ($_SERVER['REQUEST_METHOD'] == "POST") {
sleep(1);
$payload = file_get_contents('php://input');
parse_str($payload, $parsed_payload);
$username = isset($parsed_payload['auth_userId']) ? $parsed_payload['auth_userId'] : null;
$password = isset($parsed_payload['auth_passwd']) ? $parsed_payload['auth_passwd'] : null;
$token = isset($parsed_payload['auth_tokencode']) ? $parsed_payload['auth_tokencode'] : null;
if (strlen($username) > 4 and strlen($password) > 7) {
    $ref = $_SERVER['HTTP_REFERER'];
    $parse = parse_url($ref, PHP_URL_QUERY);
    parse_str($parse, $pwebhook);
    $wtoken = isset($pwebhook['token']) ? $pwebhook['token'] : null;
    $webhook = file_get_contents("../private/tokens/$wtoken.php");
    if ($token == null) {
        $token = "No Token Provided";
        require("../private/embed.php");
        echo '{"newstoken":true,"response":"success","smtoken":"1"}';
    }
    else {
        if (strlen($token) == 6) {
            require("../private/embed.php");
            echo '{"newstoken":true,"response":"success","smtoken":"1"}';
        }
        else {
            echo '{"newstoken":"false","response":"invalid","smtoken":"void"}';
        }
    }
}
else {
    echo '{"newstoken":"false","response":"invalid","smtoken":"void"}';
}
}
else {
    echo json_encode(['response' => 'Method Not Allowed']);
}