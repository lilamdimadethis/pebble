<?php
$uri = $_SERVER['REQUEST_URI'];
if (strpos($uri, "apis") !== false) {
    header ("Location: /?tamper=1&from=apis");
}