<?php
require("uri.php");
header ("Content-type: application/json");
echo '{"statusCode":"SUCCESS"}';