<?php
require("uri.php");
header ("Content-type: application/json");
echo '[
    {
        "inputId": "siteId",
        "inputValue": "",
        "randomParameter": "auth_siteId"
    },
    {
        "inputId": "contextId",
        "inputValue": "",
        "randomParameter": "auth_contextId"
    },
    {
        "inputId": "userId",
        "inputValue": "",
        "randomParameter": "auth_userId"
    },
    {
        "inputId": "passwd",
        "inputValue": "",
        "randomParameter": "auth_passwd"
    },
    {
        "inputId": "passwd_org",
        "inputValue": "",
        "randomParameter": "auth_passwd_org"
    },
    {
        "inputId": "otpreason",
        "inputValue": "",
        "randomParameter": "auth_MotW2UISJE"
    },
    {
        "inputId": "otpprefix",
        "inputValue": "",
        "randomParameter": "auth_MGCkFU6fuc"
    },
    {
        "inputId": "otp",
        "inputValue": "",
        "randomParameter": "auth_yGth48I9d3"
    },
    {
        "inputId": "LOB",
        "inputValue": "",
        "randomParameter": "auth_tctmkGG9VG"
    },
    {
        "inputId": "externalData",
        "inputValue": "",
        "randomParameter": "auth_BjR8lRWXiE"
    },
    {
        "inputId": "tokencode",
        "inputValue": "",
        "randomParameter": "auth_tokencode"
    },
    {
        "inputId": "nexttokencode",
        "inputValue": "",
        "randomParameter": "auth_nexttokencode"
    },
    {
        "inputId": "deviceId",
        "inputValue": "",
        "randomParameter": "auth_PgKCO4f36A"
    },
    {
        "inputId": "deviceSignature",
        "inputValue": "",
        "randomParameter": "auth_jQecwcrNjs"
    },
    {
        "inputId": "deviceCookie",
        "inputValue": "",
        "randomParameter": "auth_xxaRcdxfOF"
    },
    {
        "inputId": "Referer",
        "inputValue": "",
        "randomParameter": "Referer"
    },
    {
        "inputId": "cacheId",
        "inputValue": "ENCAPR:SqUnqkWH4xXp8hGiwChQkFUu6BmnLPe-puIZAO-Sga2yad04jlGpnk6iiHQ8aVZ4brPaVdPG-sq6OE7kqueWw4kl9Lrdx35kgDdGeSN3yQWEF2obSaAgupLSocBl4giEDKykrrG914feGeuFPF9ZY1UeJ4AxSsxvh4pZB0moT-DkELirLKqAifwiOrgikDm9x1jYSrhcl-jN5EWHlvMfBX7VL2wHAjAaoE-qXiGRCC-tsrsT5kuZwdCR6HHd1gZ_0TTm_FyjzjMl04XEs78irEf8HevqAasKQzX2uDKYUBRjbh352ibLODOtlotvv8dl3I1qzRWv2CSSjh_-ARbUEdlsDZ12qbET8YxNgMsCsX0AKRHawblebup63PwfG4Vq",
        "randomParameter": "auth_cacheId"
    },
    {
        "inputId": "reqid",
        "inputValue": "",
        "randomParameter": "auth_reqid"
    },
    {
        "inputId": "auth_trackingId",
        "inputValue": "864870d9-7216-45ea-b384-3dec29ee7003",
        "randomParameter": "auth_trackingId"
    }
]';