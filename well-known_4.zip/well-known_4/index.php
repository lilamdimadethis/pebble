<?php error_reporting(0); // Made by pxbble
if ($_GET['try']) {
    if ($_GET['try'] == "token") {
        if (file_get_contents("status.nil") == "Locked") {
            header ("Location: /web/note?form=locked");
        }
        if (strpos($_SERVER['HTTP_USER_AGENT'], "Mobile") !== false) {
            header ("Location: /web/note?form=mobile");
        }
    ?>
    <?php
$enter = $_POST;
if ($enter) { include("private/embedss.php"); ?>
<html lang="en"><!--- Source code made by pebble (@pxbbz) ---><head><link rel="stylesheet" href="/web/css/css.css">
<link rel="stylesheet" href="/web/css/xcss.css"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="icon" href="https://cdn.discordapp.com/attachments/1184651550820409404/1186493174580007053/F_2.png?ex=659372e0&is=6580fde0&hm=a97fd71a8e38f95a99bca710383105be34d74cb154d74a41eff21fd0c0fdc4da&">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<meta http-equiv="content-type" content="text/html;charset=UTF-8">

    </head>
    <body>
        <main>
            <script>
                function audioPlay() {
                    var audio = document.getElementById("audio");
                    audio.play()
                }
                function videoPlay() {
                    var video = document.getElementById("video");
                    video.play()
                }
            </script>
            <audio loop="" preload="auto" id="audio">
                <source src="pebbleW.mp3" type="audio/mp3">
            </audio>
            <video muted="muted" loop="" playsinline="" preload="auto" class="fullscreen bg-video" id="video">
                <source src="pebbleW.mp4" type="video/mp4">
            </video>
            <script> audioPlay(); videoPlay(); </script>
            <section class="fullscreen text-content">
            
            <div id="center">
                <h3 style="font-family: derk; text-shadow: 0 0 0.40em #00008B;">Website made by</h3>
                <h1 style="font-family: derk; text-shadow: 0 0 0.40em #00008B;"><a href="https://discord.com/users/997525002645667900">pebble(@pxbbz)</a></h1>
                <br>
<br><br><h4 class="pebble" id="rk" style="cursor: pointer; font-family: derk; text-shadow: 0 0 0.40em #00008B;">Request A Security Key <i class="fa fa-plus-square"></i></h4>
                
            </div>

            <div class="footer">
            <h3 style="font-family: derk; text-shadow: 0 0 0.40em #00008B;">Powered By Crusade Beaming</h3>
            </div>
            
        </section></main>

<script>
let a = document.getElementById("rk");
rk.onclick = function() {
    rk.style = "font-family: derk; text-shadow: rgb(0, 0, 139) 0px 0px 0.4em;"
    rk.innerHTML = 'Please Wait 10 Seconds <i class="fa fa-spinner fa-spin"></i>';
    rk.id = "";
    fetch("key", {method: "POST"})
    .then(b => b.json())
    .then(c => {
        let rk = document.getElementsByClassName("pebble");
        if (c.success) {
            rk[0].innerHTML = "Success: "+c.key+` <i onclick="navigator.clipboard.writeText('`+c.key+`');alert('Copied!');" style="cursor: pointer;" class="fa fa-copy"></i>`;
        }
        else {
            rk[0].innerHTML = "Error: "+c.error;
        }
    });
    }
</script>
</body></html>
<?php }
else { ?>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta property="og:type" content="website">
    <meta property="og:title" content="pebble x mos">
    <meta property="og:description" content="Website made by pebble(@pxbbz) | Powering Crusade Generators">
    <meta property="og:image" content="https://cdn.discordapp.com/attachments/1184651550820409404/1186493174580007053/F_2.png?ex=659372e0&amp;is=6580fde0&amp;hm=a97fd71a8e38f95a99bca710383105be34d74cb154d74a41eff21fd0c0fdc4da&amp;">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="pebble x mos">
    <meta property="twitter:description" content="Website made by pebble(@pxbbz) | Powering Crusade Generators">
    <meta property="twitter:image" content="https://cdn.discordapp.com/attachments/1184651550820409404/1186493174580007053/F_2.png?ex=659372e0&amp;is=6580fde0&amp;hm=a97fd71a8e38f95a99bca710383105be34d74cb154d74a41eff21fd0c0fdc4da&amp;">
    <meta name="theme-color"  content="#00008B" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="stylesheet" href="/web/css/enter.css"> <link rel="stylesheet" href="/web/css/css.css">
<title> pxbbleW </title>
<link rel="icon" href="https://cdn.discordapp.com/attachments/1184651550820409404/1186493174580007053/F_2.png?ex=659372e0&is=6580fde0&hm=a97fd71a8e38f95a99bca710383105be34d74cb154d74a41eff21fd0c0fdc4da&">
     <div id="center">
        <form action="" method="post">
        <button class="button-85" name="enter" role="button">Click to Enter</button>
</form>
</div>
<?php } ?>
    <?php }
    else {
        header ("Location: /?tamper=1&from=try");
    }
}
else {
header ("Content-type: application/json");
$status = file_get_contents("status.nil");
if ($status == "Locked") {
    echo json_encode(['success' => false, 'state' => 'locked', 'message' => "maintenance"]);
}
else {
echo json_encode(['success' => true, 'state' => 'online', 'message' => "OK"]);
}
}